PA7 - NoFiles
=============
A programming assignment, in two parts, to focus on terminal I/O, conditional tests, state variables, mathematical expressions, loops, methods, and arrays.
