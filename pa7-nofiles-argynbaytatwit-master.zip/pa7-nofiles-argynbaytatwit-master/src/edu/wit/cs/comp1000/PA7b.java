package edu.wit.cs.comp1000;

import java.util.Scanner;

public class PA7b {

    /**
     * Program execution point:
     * input text via console input,
     * output counts for each letter
     * found in the input (case-insensitive)
     *
     * @param args command-line arguments (ignored)
     */
    public static void main(String[] args) {
        // Scanner for input
        Scanner input = new Scanner(System.in);
        
        int[] letterCounts = new int[26];
        
        System.out.printf("Enter text: ");
        
        while (input.hasNextLine()) {
            String line = input.nextLine(); 
            for (char letter : line.toCharArray()) { 
                if (Character.isLetter(letter)) { 
                    letter = Character.toLowerCase(letter); 
                    letterCounts[letter - 'a']++;
                }
            }
        }
        
        boolean first = true; 
        for (int i = 0; i < letterCounts.length; i++) {
            if (letterCounts[i] > 0) {
                if (!first) {
                    System.out.println();
                }
                System.out.printf("%c: %d", (char) (i + 'A'), letterCounts[i]); 
                first = false;
            }
        }
        System.out.println();
    }
}