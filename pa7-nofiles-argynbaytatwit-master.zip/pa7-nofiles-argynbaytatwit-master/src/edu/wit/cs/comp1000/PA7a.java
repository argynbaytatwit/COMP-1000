package edu.wit.cs.comp1000;

import java.util.Scanner;

public class PA7a {

    /**
     * Reads all values from the provided scanner into the supplied array (up to its size)
     * and returns the number of integers read.
     * 
     * @param input input source
     * @param nums destination for read integers
     * @return number of integers read
     */
    public static int readIntoArray(Scanner input, int[] nums) {
        int count = 0;
        while (input.hasNextInt() && count < nums.length) {
            nums[count] = input.nextInt();
            count++;
        }
        return count;
    }

    /**
     * Prints to the screen the average of the supplied array, up to the supplied size,
     * and all integers in the array, again up to the supplied size, that are larger than the average.
     * 
     * @param nums array of numbers
     * @param size number of valid elements
     */
    public static void printAboveAverage(int[] nums, int size) {
        if (size == 0) {
            System.out.printf("Average: %.2f%nValues above average: none%n", 0.00);
            return;
        }

        double sum = 0;
        for (int i = 0; i < size; i++) {
            sum += nums[i];
        }
        double average = sum / size;

        System.out.printf("Average: %.2f%n", average);

        boolean foundAboveAverage = false;
        System.out.printf("Values above average: ");
        for (int i = 0; i < size; i++) {
            if (nums[i] > average) {
                if (foundAboveAverage) {
                    System.out.printf(", ");
                }
                System.out.printf("nums[%d]=%d", i, nums[i]);
                foundAboveAverage = true;
            }
        }
        if (!foundAboveAverage) {
        	System.out.printf("none");
        }
        System.out.println();
        
    }

    /**
     * Program execution point:
     * input a sequence of integers (up to 100), output average of integers and those over the average.
     * 
     * @param args command-line arguments (ignored)
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] nums = new int[100];

        System.out.print("Enter up to 100 integers: ");
        int count = readIntoArray(input, nums);

        printAboveAverage(nums, count);

    }
}