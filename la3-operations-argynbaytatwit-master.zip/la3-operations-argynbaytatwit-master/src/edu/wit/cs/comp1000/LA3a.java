package edu.wit.cs.comp1000;
import java.util.Scanner;
public class LA3a {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter three numbers: ");
		double a = input.nextDouble();
		double b = input.nextDouble();
		double c = input.nextDouble();
		System.out.printf("Enter operation: ");
		String operation = input.next();
		switch(operation) {
			case "min":
				min(a,b,c);
				break;
			case "l1":
				l1(a,b,c);
				break;
			case "l2":
				l2(a,b,c);
				break;
			default:
				System.out.printf("Invalid operation!\n");
		}
	}
	public static void min(double a, double b, double c) {
		double minValue = Math.min(a, Math.min(b, c));
		System.out.printf("min(%.2f", a);
		System.out.printf(", %.2f", b);
		System.out.printf(", %.2f", c);
		System.out.printf(") = %.2f", minValue);
		System.out.println();
	}
	public static void l1(double a, double b, double c) {
		double abs = Math.abs(a) + Math.abs(b) + Math.abs(c);
		System.out.printf("l1(%.2f", a);
		System.out.printf(", %.2f", b);
		System.out.printf(", %.2f", c);
		System.out.printf(") = %.2f", abs);
		System.out.println();
	}
	public static void l2(double a, double b, double c) {
		double ans = Math.sqrt(Math.pow(a,2) + Math.pow(b,2) + Math.pow(c,2));
		System.out.printf("l2(%.2f", a);
		System.out.printf(", %.2f", b);
		System.out.printf(", %.2f", c);
		System.out.printf(") = %.2f", ans);
		System.out.println();
	}
}
