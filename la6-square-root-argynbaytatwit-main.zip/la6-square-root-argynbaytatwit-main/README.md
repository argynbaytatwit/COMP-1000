LA6 - Square Root
=================
A lab assignment, in one part, to focus on terminal I/O (including formatting), variables, mathematical expressions, conditional statements, methods, and loops.
