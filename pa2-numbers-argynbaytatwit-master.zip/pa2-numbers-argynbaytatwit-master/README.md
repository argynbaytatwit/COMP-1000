PA2 - Numerical Exercises
=========================
A programming assignment, broken into two parts, to focus on terminal I/O (including formatting), conditional tests, simple state variables, and mathematical expressions.
