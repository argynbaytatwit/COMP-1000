package edu.wit.cs.comp1000;

import java.util.Scanner;
// TODO: document this class
public class PA6a {
	
	/**
	 * Error to output if year is not positive
	 */
	static final String E_YEAR = "The year must be positive!";
	
	/**
	 * Error to output if the day is not between 0 and 6
	 */
	static final String E_DAY = "The day of January 1st must be between 0 and 6!";
	
	/**
	 * Determines if an input is a leap year
	 * 
	 * @param year year in question
	 * @return true if a leap year
	 */
	public static boolean isLeapYear(int year) {
		if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
			return true;
		}
		else {
			return false; 
		}
	}
	
	/**
	 * Outputs a month to the console
	 * 
	 * @param month title
	 * @param startDay 0=Sunday ... 6=Saturday
	 * @param numDays number of days in the month
	 * @return day of the week after the last day of the month
	 */
	public static int printMonth(String month, int startDay, int numDays) {
		int temp = startDay;
		System.out.println(month);
		for (int j = 0; j < startDay; j++) {
			System.out.printf("   ");
		}
		for (int i = 1; i < numDays + 1; i++) {
			if (startDay == 7) {
				System.out.println();
				startDay = 0;
			}
			if (i < 10) {
				System.out.printf("  %d", i);
				startDay++;
			}
			else {
				System.out.printf(" %d", i);
				startDay++;
			}
		}
		System.out.println();
		System.out.println();
		return (startDay % 7);
	}

	/**
	 * Program execution point:
	 * input year, day of the week (0-6) of january 1
	 * output calendar for that year
	 * 
	 * @param args command-line arguments (ignored)
	 */
	public static void main(String[] args) {
		// TODO: write your code here
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter the year: ");
		int year = input.nextInt();
		System.out.printf("Enter the day of the week of January 1st (0=Sunday, 1=Monday, ... 6=Saturday): ");
		int startDay = input.nextInt();
		if (year < 0) {
			System.out.println(E_YEAR);
		}
		else if (startDay < 0 || startDay > 6) {
			System.out.println(E_DAY);
		}
		else {
			
			int startDay1 = printMonth("January", startDay, 31);
			
			if (isLeapYear(year) == true) {
				int startDay2 = printMonth("February", startDay1, 29);
				int startDay3 = printMonth("March", startDay2, 31);
				int startDay4 = printMonth("April", startDay3, 30);
				int startDay5 = printMonth("May", startDay4, 31);
				int startDay6 = printMonth("June", startDay5, 30);
				int startDay7 = printMonth("July", startDay6, 31);
				int startDay8 = printMonth("August", startDay7, 31);
				int startDay9 = printMonth("September", startDay8, 30);
				int startDay10 = printMonth("October", startDay9, 31);
				int startDay11 = printMonth("November", startDay10, 30);
				int startDay12 = printMonth("December", startDay11, 31);
		
			}
			else {
				int startDay2 = printMonth("February", startDay1, 28);
				int startDay3 = printMonth("March", startDay2, 31);
				int startDay4 = printMonth("April", startDay3, 30);
				int startDay5 = printMonth("May", startDay4, 31);
				int startDay6 = printMonth("June", startDay5, 30);
				int startDay7 = printMonth("July", startDay6, 31);
				int startDay8 = printMonth("August", startDay7, 31);
				int startDay9 = printMonth("September", startDay8, 30);
				int startDay10 = printMonth("October", startDay9, 31);
				int startDay11 = printMonth("November", startDay10, 30);
				int startDay12 = printMonth("December", startDay11, 31);
				
			}
		}
	}

}
