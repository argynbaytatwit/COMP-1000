PA5 - Block Letters & Streaming Average
=======================================
A programming assignment, broken into two parts, to focus on terminal I/O (including formatting), conditional tests, state variables, mathematical expressions, loops, and methods.
