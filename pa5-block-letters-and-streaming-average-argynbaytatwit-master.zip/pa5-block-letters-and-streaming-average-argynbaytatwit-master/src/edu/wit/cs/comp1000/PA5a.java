package edu.wit.cs.comp1000;
import java.util.Scanner;
// TODO: Part a of PA5
public class PA5a {

	// TODO: main method where everything is done. Passed all JUnit tests.
	public static void main(String[] args) {
	    // TODO: write your code here
	    System.out.printf("Input message: ");
	    Scanner input = new Scanner(System.in);
	    String message = input.nextLine().toLowerCase();
	    
	    for (int i = 0; i < message.length(); i++) {
	        char letter = message.charAt(i);
	        switch (letter) {
	            case 'h':
	                h();
	                break;
	            case 'e':
	                e();
	                break;
	            case 'l':
	                l();
	                break;
	            case 'o':
	                o();
	                break;
	            case 'w':
	                w();
	                break;
	            case 'r':
	                r();
	                break;
	            case 'd':
	                d();
	                break;
	            case ' ':
	                blank();
	                break;
	            default:
	                System.out.printf("");
	                break;
	        }
	    }
	}
	public static void blank() {
		System.out.printf("%n%n%n");
	}
	public static void d() {
		System.out.printf("%n*******%n");
		System.out.printf("*     *%n");
		System.out.printf("*     *%n");
		System.out.printf(" *   * %n");
		System.out.printf("  ***  %n%n");
	}
	public static void h() {
		System.out.printf("%n*******%n");
		System.out.printf("   *   %n");
		System.out.printf("   *   %n");
		System.out.printf("   *   %n");
		System.out.printf("*******%n%n");
	}
	public static void e() {
		System.out.printf("%n*******%n");
		System.out.printf("*  *  *%n");
		System.out.printf("*  *  *%n");
		System.out.printf("*  *  *%n");
		System.out.printf("*  *  *%n%n");
	}
	public static void l() {
		System.out.printf("%n*******%n");
		System.out.printf("*      %n");
		System.out.printf("*      %n");
		System.out.printf("*      %n");
		System.out.printf("*      %n%n");
	}
	public static void o() {
		System.out.printf("%n*******%n");
		System.out.printf("*     *%n");
		System.out.printf("*     *%n");
		System.out.printf("*     *%n");
		System.out.printf("*******%n%n");
	}
	public static void w() {
		System.out.printf("%n*******%n");
		System.out.printf("*      %n");
		System.out.printf("****   %n");
		System.out.printf("*      %n");
		System.out.printf("*******%n%n");
	}
	public static void r() {
		System.out.printf("%n*******%n");
		System.out.printf("   *  *%n");
		System.out.printf("  **  *%n");
		System.out.printf(" * ****%n");
		System.out.printf("*      %n%n");
	}
}
