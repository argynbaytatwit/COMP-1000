package edu.wit.cs.comp1000;
import java.util.Scanner;
// TODO: Part b of PA5
public class PA5b {

	// TODO: main method where everything is done. Passed all JUnit tests.
	public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char repeat;

        do {
            double average = calculateAverage(input);
            System.out.printf("The average is: %.2f%n", average);
            System.out.print("Do you want to compute another average (y/n)? ");
            repeat = input.next().toLowerCase().charAt(0); 

        } while (repeat == 'y');  
    }

    public static double calculateAverage(Scanner input) {
        int count = 0;
        double sum = 0;

        System.out.print("Enter a stream of non-negative numbers (negative when finished): ");

        while (true) {
            double number = input.nextDouble();  

            if (number < 0) {
                break;
            }
            sum += number;
            count++;
        }
        if (count == 0) {
            return 0.0;
        } else {
            return sum / count;
        }
    }
}