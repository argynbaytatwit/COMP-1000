package edu.wit.cs.comp1000;

import java.util.Scanner;
public class LA2a {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter number of sides: ");
		System.out.printf("Enter side length: ");
		int n = input.nextInt();
		double s = input.nextDouble();
		if (n < 3) {
				System.out.println("A polygon must have at least 3 sides.");
		}
		else {
			if (s <= 0.0){
			System.out.println("Side length must be positive.");
			}
			else {
				System.out.printf("Area: %.3f\n", (s * s * n)/(4*Math.tan(Math.PI/n)));
				System.out.printf("Perimeter: %.3f\n", s*n);
				double interior = 180.0 - 360.0/n;
				System.out.printf("Interior Angle: %.3f", interior);
				System.out.println(" degrees");
			}
		}
	}
}
