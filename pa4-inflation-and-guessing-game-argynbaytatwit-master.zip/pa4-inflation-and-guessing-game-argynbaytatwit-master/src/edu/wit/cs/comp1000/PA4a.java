package edu.wit.cs.comp1000;
import java.util.Scanner;
//TODO: Assignment PA4. To calculate the future price using the inflation, starting price, and number of years.
public class PA4a {

	// TODO: The method where everything is done.
	public static void main(String[] args) {
		// TODO: write your code here
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter the current price of the item: $Enter the number of years: Enter the inflation rate as a percentage: ");
		double price = input.nextDouble();
		int years = input.nextInt();
		double inflation = input.nextDouble();
		double future = price*(Math.pow(1.0 + inflation/100.0, years));
		if (years < 0) {
			System.out.println("The number of years must be at least 0!");
		}
		else if (price < 0) {
			System.out.println("The current price must be at least 0!");
		}
		else if (inflation < 0) {
			System.out.println("The inflation rate must be at least 0!");
		}
		else if (years ==1){
			System.out.printf("After 1 year, the price will be $");
			System.out.printf("%.2f\n", future);
		}
		else {
			System.out.printf("After " + years + " years, the price will be $");
			System.out.printf("%.2f\n", future);
		}
	}

}
