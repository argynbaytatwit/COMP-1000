package edu.wit.cs.comp1000;

import java.util.Random;
import java.util.Scanner;
//TODO: document this class
public class PA4b {

	// TODO: document this method
	public static void main(String[] args) {
		
		//////////////////////////////////////////////////////////////////////////////
		// DO NOT CHANGE IN FINAL SUBMISSION
		//////////////////////////////////////////////////////////////////////////////
		
		Long seed;
		if (args.length != 1) {
			seed = null; // you can temporarily change this to assist in debugging
			             // the value must end in L, such as 1070L
		} else {
			seed = Long.valueOf(args[0]);
		}
		
		// Gets a random number between 1 and 100
		// Use the target variable as the correct answer for guessing
		Random random;
		if (seed == null) {
			random = new Random();
		} else {
			random = new Random(seed);
		}
		int target = (Math.abs(random.nextInt()) % 100) + 1;
		
		//////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////
		
		// TODO: write your code here	
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter your guess (between 1 and 100): ");
		int number = input.nextInt();
		while (number != target) {
			if (number < 1 || number > 100) {
				System.out.println("Invalid guess, try again!");
			}
			else if (number > target){
				System.out.println("Too high!");
			}
			else if (number < target) {
				System.out.println("Too low!");
			}
			System.out.printf("Enter your guess (between 1 and 100): ");
			number = input.nextInt();
		}
		System.out.println("You win!");
	}	
}
