PA4 - Inflation & Guessing Game
===============================
A programming assignment, broken into two parts, to focus on terminal I/O (including formatting), conditional tests, state variables, mathematical expressions, and loops.
