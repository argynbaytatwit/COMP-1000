package edu.wit.cs.comp1000;
import java.util.Scanner;
public class LA1a {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double a,b,c,d,e, sum,mean,sd;
		System.out.printf("Enter five numbers: ");
		a=input.nextDouble();
		b=input.nextDouble();
		c=input.nextDouble();
		d=input.nextDouble();
		e=input.nextDouble();
		
		System.out.printf("Sum: %.2f", summary(a,b,c,d,e));
		System.out.printf("\nMean: %.2f", mean(summary(a,b,c,d,e)));
		System.out.printf("\nPopulation Standard Deviation: %.2f", standard_deviation(a,b,c,d,e));
		System.out.println();
	}
	public static double summary(double a, double b, double c, double d, double e) {
		return (a + b + c + d + e);
	}
	public static double mean(double summary) {
		return summary/5.0;
	}
	public static double standard_deviation(double a, double b, double c, double d, double e) {
		double mean = (a+b+c+d+e)/5;
		double sum1 = (mean - a)*(mean - a) + (mean - b)*(mean - b) + (mean - c)*(mean - c) + (mean - d)*(mean - d) + (mean - e)*(mean - e);
		return Math.sqrt(sum1/5.0);
	}
}
