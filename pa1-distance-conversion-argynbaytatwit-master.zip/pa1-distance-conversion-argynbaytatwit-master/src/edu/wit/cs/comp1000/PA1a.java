package edu.wit.cs.comp1000;
import java.util.Scanner;
// TODO: document this class
/*
 * Solution to the first programming assignment Part A.
 * 
 * @author Temirlan Argynbay
 */
public class PA1a {

	// TODO: document this function
	/*
	 * When it runs it gets yards, feet and inches and outputs "total inches to
	 * the terminal.
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter number of yards: ");
		int yards = input.nextInt();
		System.out.printf("Enter number of feet: ");
		int feet = input.nextInt();
		System.out.printf("Enter number of inches: ");
		int inches = input.nextInt();
		int total = yards * 36 + feet * 12 + inches;
		System.out.printf("Total number of inches: " + total + "%n");
	}

}
