package edu.wit.cs.comp1000;
import java.util.Scanner;
/*
 * Solution to the first programming assignment Part B.
 * @author Temirlan Argynbay
 */
public class PA1b {

	// TODO: document this function
	/*
	 * User inputs total number of inches, program outputs how many inches, feet and yards is that
	 * right to the terminal.
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter number of inches: ");
		int inches = input.nextInt();
		int yards = inches/36;
		int feet = (inches%36)/12;
		int inches_left = inches - yards* 36 - feet * 12;
		System.out.printf("Yards: " + yards);
		System.out.printf("%nFeet: " + feet);
		System.out.printf("%nInches: " + inches_left + "%n");
	}

}
