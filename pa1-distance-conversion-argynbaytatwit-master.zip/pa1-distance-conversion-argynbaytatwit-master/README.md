PA1 - Distance Conversion
=========================
A programming assignment, broken into two parts, to focus on terminal I/O and simple mathematical expressions.
