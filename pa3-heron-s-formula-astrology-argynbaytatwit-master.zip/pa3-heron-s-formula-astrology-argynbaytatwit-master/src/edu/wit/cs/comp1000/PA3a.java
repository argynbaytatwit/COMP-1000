package edu.wit.cs.comp1000;

import java.util.Scanner;

//TODO: Writing a program to evaluate the area of a triangle given the lengths of its sides using Heron's Formula.
public class PA3a {

	// TODO: import the sides and calculate with Math.
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter the length of side a: Enter the length of side b: Enter the length of side c: ");
		double a,b,c;
		a = input.nextDouble();
		b= input.nextDouble();
		c= input.nextDouble();
		double s = (a+b+c)/2;
		double area = Math.sqrt(s*(s-a)*(s-b)*(s-c));
		if ((a<=0 || b <= 0 || c <= 0)) {
			System.out.printf("Side lengths must all be positive%n");
		}
		else if ((a + b > c) &&(b+c>a)&&(a+c>b)){
			System.out.printf("The area is %.2f", area);
			System.out.println();
		}
		else if (a + b < c){
			System.out.println("Side c is too long");
		}
		else if (a + c < b) {
			System.out.println("Side b is too long");
		}
		else if (b + c < a) {
			System.out.println("Side a is too long");
		}
	}

}
