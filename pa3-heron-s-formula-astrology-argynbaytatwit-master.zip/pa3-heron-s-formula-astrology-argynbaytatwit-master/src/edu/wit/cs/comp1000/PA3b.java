package edu.wit.cs.comp1000;
import java.util.Scanner;
//TODO: Writing an astrology program based on person's birthday.
public class PA3b {

	// TODO: writing a lot of if statements.
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.printf("Enter your birth month (1-12): Enter your birth day (1-31): ");
		int month = input.nextInt();
		int day = input.nextInt();
		if (day <=0 || day > 31) {
			System.out.println("Day must be between 1 and 31!");
		}
		else if (month <= 0 || month >12) {
			System.out.println("Month must be between 1 and 12!");
		}
		else {
			if ((month == 3 && day >=21) || (month ==4 && day <=19)) {
				System.out.println("You are an Aries!");
				System.out.println("You are lucky today!");
			}
			else if((month == 4 && day >=20) || (month ==5 && day <=20)) {
				System.out.println("You are a Taurus!");
				System.out.println("You are lucky today!");
			}
			else if((month == 5 && day >=21) || (month ==6 && day <=21)) {
				System.out.println("You are a Gemini!");
				System.out.println("You are lucky today!");
			}
			else if((month == 6 && day >=22) || (month ==7 && day <=22)) {
				System.out.println("You are a Cancer!");
				System.out.println("You are lucky today!");
			}
			else if((month == 7 && day >=23) || (month ==8 && day <=22)) {
				System.out.println("You are a Leo!");
				System.out.println("You are lucky today!");
			}
			else if((month == 8 && day >=23) || (month ==9 && day <=22)) {
				System.out.println("You are a Virgo!");
				System.out.println("You are lucky today!");
			}
			else if((month == 9 && day >=23) || (month ==10 && day <=22)) {
				System.out.println("You are a Libra!");
				System.out.println("You are lucky today!");
			}
			else if((month == 10 && day >=23) || (month ==11 && day <=21)) {
				System.out.println("You are a Scorpio!");
				System.out.println("You are lucky today!");
			}
			else if((month == 11 && day >=22) || (month ==12 && day <=21)) {
				System.out.println("You are a Sagittarius!");
				System.out.println("You are lucky today!");
			}
			else if((month == 12 && day >=22) || (month ==1 && day <=19)) {
				System.out.println("You are a Capricorn!");
				System.out.println("You are lucky today!");
			}
			else if((month == 1 && day >=20) || (month ==2 && day <=18)) {
				System.out.println("You are an Aquarius!");
				System.out.println("You are lucky today!");
			}
			else if((month == 2 && day >=19) || (month ==3 && day <=20)) {
				System.out.println("You are a Pisces!");
				System.out.println("You are lucky today!");
			}
		}
	}

}
