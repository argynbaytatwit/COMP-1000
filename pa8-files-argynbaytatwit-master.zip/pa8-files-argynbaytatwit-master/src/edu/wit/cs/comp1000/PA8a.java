package edu.wit.cs.comp1000;

import java.io.PrintWriter;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;



//TODO: document this class
public class PA8a {
	
	/**
	 * Error to output when a file cannot be opened.
	 */
	static final String E_NOT_FOUND = "Error! File not found!";
	
	/**
	 * Reads all integers in input scanner,
	 * outputs positive ones to output each on
	 * its own line
	 * 
	 * @param input input source
	 * @param output output destination 
	 */
	public static void process(Scanner input, PrintWriter output) {
		
		while (input.hasNextInt()) {
			int number = input.nextInt();
			if (number > 0) {
				output.println(number);
			}
		}
	}
	
	/**
	 * Program execution point:
	 * input an input file name and an output file name,
	 * for each positive number in the input file 
	 * print on its own line to the output file
	 * 
	 * @param args command-line arguments (ignored)
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String name_input, name_output;
		System.out.print("Enter the name of the input file: ");
		name_input = input.next();
		System.out.print("Enter the name of the output file: ");
		name_output = input.next();

		try (Scanner inputScanner = new Scanner(new File(name_input))){
			try (PrintWriter outputWriter = new PrintWriter(new File(name_output))) {
				process(inputScanner, outputWriter);
				outputWriter.close();
			}
			catch (FileNotFoundException e) {
				System.out.printf(E_NOT_FOUND + "%n");
				System.exit(0);
			} 
			
			inputScanner.close();
			
		} 
		
		catch (FileNotFoundException e) {
			System.out.printf(E_NOT_FOUND + "%n");
			System.exit(0);
		} 
		
		input.close();
		
	}
}
