package edu.wit.cs.comp1000;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class PA8b {

    /**
     * Program execution point:
     * input an input file name,
     * output the smallest and largest
     * integers found in the file (or invalid
     * if not only integers in the file)
     * 
     * @param args command-line arguments (ignored)
     */
    public static void main(String[] args) {
        Scanner input_name = new Scanner(System.in);
        System.out.printf("Enter the name of the input file: ");
        String filename = input_name.next();
        File input_file = new File(filename);

        int lowest = Integer.MAX_VALUE;
        int highest = Integer.MIN_VALUE;
        boolean hasValidIntegers = false;

        try (Scanner input2 = new Scanner(input_file)) {
            while (input2.hasNext()) {
                if (input2.hasNextInt()) {
                    int number = input2.nextInt();
                    lowest = Math.min(lowest, number);
                    highest = Math.max(highest, number);
                    hasValidIntegers = true;
                } else {
                    // If a non-integer is found, print invalid and stop processing
                    System.out.printf("File: invalid%n");
                    return;
                }
            }

            if (hasValidIntegers) {
                System.out.printf("File: [%s, %s]%n", lowest, highest);
            } else {
                System.out.printf("File: invalid%n");
            }

        } catch (FileNotFoundException e) {
            System.out.printf("File: invalid%n");
        }
    }
}